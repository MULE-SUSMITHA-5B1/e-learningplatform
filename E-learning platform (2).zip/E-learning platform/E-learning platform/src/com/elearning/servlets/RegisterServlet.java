package com.elearning.servlets;

import com.elearning.dao.UserDAO;
import com.elearning.model.User;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Get form data from register.jsp
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password"); // Hash in real projects
        String role = request.getParameter("role");

        System.out.println("Received form data: " + name + ", " + email + ", " + password + ", " + role);

        // Validate form inputs
        if (name == null || email == null || password == null || role == null ||
            name.isEmpty() || email.isEmpty() || password.isEmpty() || role.isEmpty()) {
            request.setAttribute("errorMessage", "All fields are required!");
            request.getRequestDispatcher("register.html").forward(request, response);

            return;
        }

        // Create a new User object
        User user = new User(name, email, password, role);

        // Register the user in the database
        boolean isRegistered = UserDAO.registerUser(user);

        if (isRegistered) {
            System.out.println("User registered successfully!");
            response.sendRedirect("login.jsp?message=Registration successful! Please login.");
        } else {
            request.setAttribute("errorMessage", "Registration failed. Try again.");
            request.getRequestDispatcher("register.html").forward(request, response);

        }
        if (!isRegistered) {
            request.setAttribute("errorMessage", "Email already exists! Please use another email.");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

    }
    
}
