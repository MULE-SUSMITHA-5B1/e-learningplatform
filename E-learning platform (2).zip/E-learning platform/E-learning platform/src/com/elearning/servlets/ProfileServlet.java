package com.elearning.servlets;

import com.elearning.dao.UserDAO;
import com.elearning.model.User;
import java.io.IOException;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class ProfileServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect("login.html"); // Redirect to login if not authenticated
            return;
        }

        request.setAttribute("user", user);
        request.getRequestDispatcher("profile.jsp").forward(request, response); // Load profile page
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get user session
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect("login.html");
            return;
        }

        // Get updated profile details from request
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password"); // Consider hashing before storing

        // Update user object
        user.setName(name);
        user.setEmail(email);
        if (password != null && !password.isEmpty()) {
            user.setPassword(password); // Update password if provided
        }

        // Update user in the database
        boolean updateStatus = UserDAO.updateUser(user);

        if (updateStatus) {
            session.setAttribute("user", user); // Update session with new user details
            response.sendRedirect("profile.jsp?success=Profile updated successfully");
        } else {
            response.sendRedirect("profile.jsp?error=Update failed! Try again.");
        }
    }
}
