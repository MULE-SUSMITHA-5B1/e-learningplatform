console.log("E-Learning Platform Loaded");
